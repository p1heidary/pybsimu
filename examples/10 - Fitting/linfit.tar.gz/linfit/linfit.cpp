/* (c) Jan Saren 2013
 * jan.saren@jyu.fi
 * 
 * This is still under construction -> use with care
 *
 * Revised by Taneli Kalvas 2014
 *  - Read a selected dependent column
 *  - Possibility to read in from a file
 *  - Changed read_data() to check line-by-line, added error checking
 *  - Added an inline help
 *
 */


#include <cstring>

#include <stdio.h>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <gsl/gsl_multifit.h>
#include <gsl/gsl_statistics_double.h>


using namespace std;



/* Global variables */
bool _help = false;             /* Print help */
size_t _samplec   = 0;          /* Number of observations */
size_t _ivarc     = 1;          /* Number of independent variables (like x, y, ...) */
size_t _depcol    = 0;          /* Dependent column selected, 0 = first after independent variables */
size_t _polyorder = 1;          /* Polynome order. 2 means for example:
				 *   y_i = c0 + c1*x + x2*y + c11*x*x + c12*x*y + c22*y*y
				 * if _ivarc == 2 */
size_t _basefunctionc = 0;      /* Number of basis. This is updated in function 
				 * count_autopolynomecoeffc() */

size_t _max_samplec = (size_t)-1;    /* Maximum number of samples */

int    _verbosity   = 1;        /* Verbosity: 0 = nothing -- 4 = everything */



gsl_matrix   *_X      = 0;      /* Matrix of predictor variables */
gsl_matrix   *_cov    = 0;      /* Covariance matrix */
gsl_vector   *_y      = 0;      /* Vector of observations */
gsl_vector   *_c      = 0;      /* Vector of best-fit parameters (c0, c1, c11, ..., c12223, ... ) */
double        _chisq  = 0;      /* Chi squared */



int      _polyterms[300][10];   /* Tells which basis constituent to this coefficient. 
				 * First index is number of the base and second is independent 
				 * variable number attached. Example if independent variables 
				 * are v0, v1, and v2 then the term 17 (v1*v1*v2) will be:
				 *   _polyterms[17][0] = 2, _polyterms[17][1] = 1 and
				 *   _polyterms[17][2] = 1 */

int      _polyorders[300];      /* Orders of the terms. Example: _polyorders[17] = 3 
				 * (with three independent variables) */

string _infile;
string   _comparisonfile;

vector< vector<double> >  _tmp_xs;



void process_arguments( int argc, char *argv[] );
void help();
void count_autopolynome_basefunctionc();
void read_data();
void solve();
void print_report();
void print_equation();
void free_memory();



inline double evaluate_base( const size_t &rec, 
			     const size_t &basei, 
			     const vector< vector<double> > &xs );

void print_base_index( ostream &os, const size_t &basei );
void print_base( ostream &os, const size_t &basei );





template <class T>
inline std::string to_string( const T& t )
{
    std::stringstream ss;
    ss << t;
    return( ss.str() );
}





int main( int argc, char *argv[] )
{
    try {
	
	process_arguments( argc, argv );
	if( _help ) {
	    help();
	    return( 0 );
	}
	count_autopolynome_basefunctionc();
	read_data();
	solve();
	print_report();
	print_equation();
	free_memory();

	
    } catch( string s ) {
	cerr << "Error message: \'" << s << "\'\n";
    }
    
    return( 0 );
}







void process_arguments( int argc, char *argv[] )
{
    if( argc == 1 ) {
	_help = true;
	return;
    }

    if( _verbosity >= 4 )
	cout << "process_arguments():\n";
    

    int i = 1;
    while( i < argc ) {

	if( _verbosity >= 3 )
	    cout << "Processing argument argv[" << i << "] = \'" << argv[i] << "\'\n";


	if( !strcmp( argv[i], "--ivarc" ) ) {
	    _ivarc = atoi( argv[i+1] );
	    ++i;
	    
	    if( _ivarc > 10 ) {
		throw string( "Too many independent variables" );
	    }

	    if( _verbosity >= 2 ) 
		cout << "set _ivarc = " << _ivarc << "\n";
	}
	else if( !strcmp( argv[i], "--help" ) ) {
	    _help = true;
	    return;
	}
	else if( !strcmp( argv[i], "--max_samplec" ) ) {
	    _max_samplec = atoi( argv[i+1] );
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _max_samplec = " << _max_samplec << "\n";
	}
	else if( !strcmp( argv[i], "--depcol" ) ) {
	    _depcol = atoi( argv[i+1] );
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _depcol = " << _depcol << "\n";
	}
	else if( !strcmp( argv[i], "--polyorder" ) ) {
	    _polyorder = atoi( argv[i+1] );
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _polyorder = " << _polyorder << "\n";
	}
	else if( !strcmp( argv[i], "--verbosity" ) ) {
	    _verbosity = atoi( argv[i+1] );
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _verbosity = " << _verbosity << "\n";
	}
	else if( !strcmp( argv[i], "--comparisonfile" ) ) {
	    _comparisonfile = argv[i+1];
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _comparisonfile = " << _comparisonfile << "\n";
	}
	else if( !strcmp( argv[i], "--infile" ) ) {
	    _infile = argv[i+1];
	    ++i;
	    if( _verbosity >= 2 ) 
		cout << "set _infile = " << _infile << "\n";
	}

	/*
	else if( !strcmp( argv[i], "--tm" ) ) {
	    b_transfer_matrix = 1;
	}
	else if( !strcmp( argv[i], "--eq" ) ) {
	    b_print_equation = 1;
	}
	else if( !strcmp( argv[i], "--differencefile" ) ) {
	    if( argv[i+1] != NULL ) {
		strncpy( ac_differencefile, argv[i+1], 999 );
		ac_differencefile[999] = '\0';
	    }
	    ++i;
	}
	else if( !strcmp( argv[i], "--inputfile" ) ) {
	    if( argv[i+1] != NULL ) {
		strncpy( ac_inputfile, argv[i+1], 999 );
		ac_inputfile[999] = '\0';
	    }
	    ++i;
	}
	else if( !strcmp( argv[i], "--savecoeffstofile" ) ) {
	    if( argv[i+1] != NULL ) {
		strncpy( ac_coefffile, argv[i+1], 999 );
		ac_coefffile[999] = '\0';
		b_save_coeffs = 1;
	    }
	    ++i;
	}
	else if( !strcmp( argv[i], "--saveeqfile" ) ) {
	    if( argv[i+1] != NULL ) {
		strncpy( ac_eqfile, argv[i+1], 999 );
		ac_eqfile[999] = '\0';
		b_save_eq = 1;
	    }
	    ++i;
	}
	*/
	else {
	    cerr << "command \'" << argv[i] << "\' is undefined!\n";
	    throw string( "command undefined" );
	}
	++i;
    }
    
}






void help()
{
    cout << "Linfit, 21 October 2014\n"
	 << "(c) Jan Saren 2013-2014\n"
	 << "jan.saren@jyu.fi\n"
	 << "\n"
	 << "Usage: linfit [OPTIONS]\n"
	 << "Fit a Nth degree polynomial with K independent variables to data using least squares method\n"
	 << "\n"
	 << "Options:\n"
	 << "  --infile FILE           Set input file (defaults to stdin)\n"
	 << "  --ivarc K               Set independent variable count\n"
	 << "  --polyorder N           Set order of polynomial\n"
	 << "  --verbosity V           Set verbosity level (0-4)\n"
	 << "  --max_samplec S         Set maximum number of samples to read (defaults to inf)\n"
	 << "  --comparisonfile FILE   Output comparison file\n"
	 << "  --depcol D              Set dependent column number to use (defaults to 0,\n"
	 << "                            which is the first column after the independent variables)\n"
	 << "\n"
	 << "Input file format consists of at least K+D+1 columns. Each line is a single sample.\n"
	 << "First K columns contain the independent variables and the following columns contain\n"
	 << "the dependent variables. A selected dependent column is used for fitting.\n";
}







void count_autopolynome_basefunctionc()
{
    if( _verbosity >= 4 )
	cout << "count_autopolynome_basefunctionc():\n";

    if( _polyorder < 0 )
	throw string( "count_autopolynomecoeffc() needs positive polyorder" );

    unsigned int ai_tmp[_polyorder+1];
    unsigned int i, count;
    unsigned int i_order;
    
    _polyorders[0] = 0;
  
    count = 1;
    for( i_order = 1; i_order <= _polyorder; ++i_order ) {
	
	if( _verbosity >= 4 )
	    cout << "  i_order = " << i_order << ":\n";
	
	for( i = 0; i < i_order+1; ++i )
	    ai_tmp[i] = 0;

	while( 1 ) {
	    

	    if( _verbosity >= 4 )
		cout << "    setting _polyorders[" << count << "] = " << i_order << ":\n";
	    _polyorders[count] = i_order;

	    for( i = 0; i < i_order; ++i ) {
		if( _verbosity >= 4 )
		    cout << "      setting _polyterms[" << count << "][" << i << "] = " << ai_tmp[i] << ":\n";
		_polyterms[count][i] = ai_tmp[i];
	    }
	    
	    count++;
	    
	    ++(ai_tmp[0]);
	    
	    i = 0;
	    while( i < i_order ) {
		if(ai_tmp[i] >= _ivarc ) 
		    ++(ai_tmp[i+1]);
		else 
		    break;
		++i;
	    }
	    while( i > 0 ) {
		ai_tmp[i-1] = ai_tmp[i];
		--i;
	    }
	    
	    if( ai_tmp[i_order] > 0  )
		break;
	}  
	
    }

    _basefunctionc = count;

    if( _verbosity >= 2 )
	cout << "_basefunctionc = " << _basefunctionc << "\n";
}





void process_line( const std::string &str, int linec, vector<double> &tmp_ys )
{
    // Parse line
    const char *ptr = str.c_str();
	    
    // Skip leading white space
    while( isspace(*ptr) ) ptr++;

    // Check if comment
    if( *ptr == '#' )
	return;

    // Check if line contained only white space
    if( *ptr == '\n' || *ptr == '\r' || *ptr == '\0' )
	return;

    // Read independent variable columns
    double val;
    char *endptr;
    for( unsigned int i = 0; i < _ivarc; i++ ) {

	val = strtod( ptr, &endptr );
	if( endptr == ptr ) {
	    if( *ptr == '\n' || *ptr == '\r' || *ptr == '\0' )
		throw string( "unexpected end of line reading line " + to_string(linec) + "." );
	    throw string( "unexpected input reading line " + to_string(linec) );
	}
	_tmp_xs[i].push_back( val );
	ptr = endptr;

	// Skip white space
	while( isspace(*ptr) ) ptr++;
    }

    // Read dependent variable columns
    for( unsigned int i = 0; i <= _depcol; i++ ) {

	val = strtod( ptr, &endptr );
	if( endptr == ptr ) {
	    if( *ptr == '\n' || *ptr == '\r' || *ptr == '\0' )
		throw string( "unexpected end of line reading line " + to_string(linec) + "." );
	    throw string( "unexpected input reading line " + to_string(linec) );
	}
	ptr = endptr;

	// Skip white space
	while( isspace(*ptr) ) ptr++;
    }
    tmp_ys.push_back( val );

    _samplec++;
}




void read_data()
{
    if( _verbosity >= 4 )
	cout << "read_data():\n";

    istream *fin = &cin;
    ifstream *ifin = NULL;
    if( _infile.length() != 0 ) {
	ifin = new ifstream( _infile.c_str() );
	if( !ifin->good() )
	    throw string( "couldn\'t open file \'" + _infile + "\'" );
	fin = ifin;
    }

    vector<double> tmp_ys;

    _tmp_xs.resize( _ivarc );
    _samplec = 0;

    int linec = 0;
    while( !fin->eof() && _samplec < _max_samplec ) {
	
	// Read line
	std::string str;
	std::getline( *fin, str );
	linec++;

	process_line( str, linec, tmp_ys );
    }
    
    if( ifin != NULL )
	ifin->close();

    if( _samplec < _basefunctionc )
	throw string( "too few samplelines given" );


    if( _verbosity >= 2 )
	cout << "_samplec = " << _samplec << ":\n";

    if( _verbosity >= 4 ) {

	for( unsigned int rec = 0; rec < _samplec; ++rec ) {
	    cout << rec << "\t";
	    for( unsigned int iv = 0; iv < _ivarc; ++iv ) {
		cout << _tmp_xs[iv][rec] << "\t";
	    }
	    cout << tmp_ys[rec] << "\n";
	}

    }
	

    /* Allocating gsl vectors and matrices */
    _X   = gsl_matrix_alloc( _samplec, _basefunctionc );
    _y   = gsl_vector_alloc( _samplec );
    
    _c   = gsl_vector_alloc( _basefunctionc );
    _cov = gsl_matrix_alloc( _basefunctionc, _basefunctionc );


    /* Copying data to gsl vectors */
    for( unsigned int rec = 0; rec < _samplec; ++rec ) {
	gsl_vector_set( _y, rec, tmp_ys[rec] );
	for( unsigned int basei = 0; basei < _basefunctionc; ++basei )
	    gsl_matrix_set( _X, rec, basei, evaluate_base( rec, basei, _tmp_xs ) );
    }

}


void solve()
{
    /* Allocating work memory for multifit */
    gsl_multifit_linear_workspace * work = gsl_multifit_linear_alloc( _samplec, _basefunctionc );
    
    /* Multifit */
    gsl_multifit_linear( _X, _y, _c, _cov, &_chisq, work );

    /* Freeing work space */
    gsl_multifit_linear_free( work );
}


void print_report()
{
    // not in gsl 1.10 yet
    //double tss = gsl_stats_tss( _y->data, _y->stride, _y->size );

    cout << "*************************\n"
	 << "chisq        = " << _chisq << "\n"
	 << "observations = " << _samplec << "\n";
	//<< "R^2          = " << 1 - _chisq/tss << "\n";

    for( size_t i = 0; i < _basefunctionc; ++i ) {
	cout << "c";
	print_base_index( cout, i );
	cout << " =\t" << gsl_vector_get( _c, i ) << ";\n";
    }

    
    // These are used to calculate average contribution of each base
    vector<double> basef_ave( _basefunctionc, 0 );
    vector<double> basef_sd( _basefunctionc, 0 );
    vector<double> basef_maxvalue( _basefunctionc, 0 );
    

    cout << "*************************\n";
    ofstream fcomparison;
    if( _comparisonfile.size() ) {
        fcomparison.open( _comparisonfile.c_str() );
        if( !fcomparison.is_open() ) {
            cerr << "Cannot open file " << _comparisonfile << "\n";
            _comparisonfile.clear();
        }
    }

    double diffsum = 0;
    for( unsigned int rec = 0; rec < _samplec; ++rec ) {
        double value = 0;
        for( unsigned int basei = 0; basei < _basefunctionc; ++basei ) {
            double termvalue = gsl_vector_get( _c, basei ) * evaluate_base( rec, basei, _tmp_xs );
            if( fabs(termvalue) > fabs(basef_maxvalue[basei]) )
                basef_maxvalue[basei] = termvalue;
            value += termvalue;
            basef_ave[basei] += termvalue;
        }
        
        double diff = gsl_vector_get( _y, rec ) - value;

        diffsum += diff;
        if( _comparisonfile.size() ) {
            fcomparison << rec << "\t"
                        << gsl_vector_get( _y, rec ) << "\t"
                        << value << "\t"
                        << diff << "\n";
        }

    }
    double avediff = diffsum/_samplec;

    
    for( unsigned int basei = 0; basei < _basefunctionc; ++basei )
        basef_ave[basei] /= _samplec;


    double diff2sum = 0;
    for( unsigned int rec = 0; rec < _samplec; ++rec ) {
        double value = 0;
        for( unsigned int basei = 0; basei < _basefunctionc; ++basei ) {
            double termvalue = gsl_vector_get( _c, basei ) * evaluate_base( rec, basei, _tmp_xs );
            value += termvalue;
            basef_sd[basei] += (basef_ave[basei] - termvalue) * (basef_ave[basei] - termvalue);
        }

        double diff = gsl_vector_get( _y, rec ) - value;

        diff2sum += diff*diff;
    }
    double sd = sqrt( 1./(_samplec-1.0)*diff2sum );

    for( unsigned int basei = 0; basei < _basefunctionc; ++basei )
        basef_sd[basei] = sqrt( 1./(_samplec-1.0)*basef_sd[basei] );

    cout << "avediff = " << avediff << "\n";
    cout << "sd      = " << sd << "\n";
    
    cout << "base effect: base value ave sd \n";
    for( unsigned int basei = 0; basei < _basefunctionc; ++basei ) {
	cout << "c";
	print_base_index( cout, basei );
	cout << " =\t" << setw(12) << gsl_vector_get( _c, basei ) << "\t"
             << setw(12) << basef_ave[basei] << "\t"
             << setw(12) << basef_sd[basei] << "\t"
             << setw(12) << basef_maxvalue[basei] << "\n";
    }

    cout << "*************************\n";
    

}



void print_equation()
{
    cout << "****** E Q U A T I O N ********************************\n";

    cout << "f( ";
    for( size_t i = 0; i < _ivarc; ++i ) {
	if( i > 0 )
	    cout << ", ";
	cout << "v" << i;
    }
    cout << " ) = ";
    for( size_t i = 0; i < _basefunctionc; ++i ) {
	if( i > 0 )
	    cout << " + ";
	cout << "c";
	
	print_base_index( cout, i );
	if( _polyorders[i] > 0 ) 
	    cout << "*";
	print_base( cout, i );
    }
    cout << "\n";

}



void free_memory()
{
    if( _verbosity >= 4 )
	cout << "free_memory():\n";
    
    gsl_matrix_free( _X );
    gsl_vector_free( _y );
    gsl_vector_free( _c );
    gsl_matrix_free( _cov );
}


double evaluate_base( const size_t &rec, 
		      const size_t &basei, 
		      const vector< vector<double> > &xs )
{
    double ret = 1;
    for( int orderi = 0; orderi < _polyorders[basei]; ++orderi ) {
	ret *= xs[ _polyterms[basei][orderi] ][rec];
    }
    return( ret );
}


void print_base_index( ostream &os, const size_t &basei )
{
    for( int i = 0; i < _polyorders[basei]; ++i )
	os << _polyterms[basei][i];
}


void print_base( ostream &os, const size_t &basei )
{
    for( int i = 0; i < _polyorders[basei]; ++i ) {
	if( i > 0 )
	    os << "*";
	os << "v" << _polyterms[basei][i];
    }
}

/*


int main( int argc, char *argv[] )
{
    int i, n;
    double xi, yi, ei, chisq;
    gsl_matrix *X, *cov;
    gsl_vector *y, *w, *c;
    
    if (argc != 2)
    {
	fprintf (stderr,"usage: fit n < data\n");
	exit (-1);
    }
    
    n = atoi( argv[1] );              // number of observations
    
    X = gsl_matrix_alloc(n, 3);       // matrix
    y = gsl_vector_alloc(n);          // observations
    w = gsl_vector_alloc(n);          // weights
    
    c = gsl_vector_alloc(3);          // best-fit parameters
    cov = gsl_matrix_alloc(3, 3);     
    
    for( i = 0; i < n; i++ ) {
	int count = fscanf (stdin, "%lg %lg %lg", &xi, &yi, &ei);
	
	if (count != 3) {
	    fprintf (stderr, "error reading file\n");
	    exit (-1);
	}
	
	printf ("%g %g +/- %g\n", xi, yi, ei);
        
	gsl_matrix_set( X, i, 0, 1.0 );
	gsl_matrix_set( X, i, 1, xi );
	gsl_matrix_set( X, i, 2, xi*xi );
        
	gsl_vector_set( y, i, yi );
	gsl_vector_set( w, i, 1.0/(ei*ei) );
    }
    
    
    {
	gsl_multifit_linear_workspace * work = gsl_multifit_linear_alloc( n, 3 );
	gsl_multifit_wlinear( X, w, y, c, cov, &chisq, work );
	gsl_multifit_linear_free( work );
    }
    
#define C(i) (gsl_vector_get(c,(i)))
#define COV(i,j) (gsl_matrix_get(cov,(i),(j)))
    
    {
	printf ("# best fit: Y = %g + %g X + %g X^2\n", 
		C(0), C(1), C(2));
	
	printf ("# covariance matrix:\n");
	printf ("[ %+.5e, %+.5e, %+.5e  \n",
		COV(0,0), COV(0,1), COV(0,2));
	printf ("  %+.5e, %+.5e, %+.5e  \n", 
		COV(1,0), COV(1,1), COV(1,2));
	printf ("  %+.5e, %+.5e, %+.5e ]\n", 
		COV(2,0), COV(2,1), COV(2,2));
	printf ("# chisq = %g\n", chisq);
    }
    
    gsl_matrix_free(X);
    gsl_vector_free(y);
    gsl_vector_free(w);
    gsl_vector_free(c);
    gsl_matrix_free(cov);
    
    return 0;

}
*/
