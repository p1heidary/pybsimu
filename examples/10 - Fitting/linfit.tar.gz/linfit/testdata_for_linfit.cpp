#include <iostream>
#include <cmath>

#include <gsl/gsl_randist.h>

const size_t _samplec = 100000;
const size_t _ivarc   = 3;

const double _sigma   = 0.01;




using namespace std;




int main( void ) 
{
    double               x[_ivarc];
    const gsl_rng_type * T;
    gsl_rng            * r;
    
    //gsl_rng_env_setup();
    
    T = gsl_rng_default;
    r = gsl_rng_alloc( T );

    for( size_t i = 0; i < _samplec; ++i ) 
    {
	for( size_t v = 0; v < _ivarc; ++v ) {
	    x[v] = ( gsl_rng_uniform( r )*2.0 - 1.0 )*0.5;
	    cout << x[v] << "\t";
	}

	double y0 = 0.3 + 1.2*x[0] - 0.4*x[1] + 0.9*x[2] + 2.7*x[1]*x[2] - 4.0*x[0]*x[1]*x[1];
	y0 += gsl_ran_gaussian( r, _sigma );

	double y1 = 0.1 - 7.2*x[0] + 0.2*x[1] + 1.1*x[2] + 1.7*x[1]*x[2] + 3.1*x[0]*x[0]*x[2];
	y1 += gsl_ran_gaussian( r, _sigma );
	
	cout << y0 << " " << y1 << "\n";
    }
    
    gsl_rng_free(r);
    
    return 0;
}
